from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__, template_folder='templates')


@app.route('/')
def homepage():
    return render_template('proj_index.html')

@app.route('/heart')
def heart_home():
    return render_template('heartform.html')

@app.route('/predict_heart', methods=['POST', 'GET'])
def predict_heart():
    model = pickle.load(open('models\heart_disease_model.pkl', 'rb'))
    int_features = [int(x) for x in request.form.values()]
    final = [np.array(int_features)]

    prediction = model.predict(final)
    output = '{0:{1}f}'.format(prediction[0], 2)

    if output == str(0):
        return render_template("result.html", pred="You are SAFE!!")
    else:
        return render_template("result.html", pred="You have heart disease!!")

# Placeholder for diabetes form handling
@app.route('/diabetes')
def diabetes_home():
    return render_template('diabetesform.html')

@app.route('/predict_diabetes', methods=['POST', 'GET'])
def predict_diabetes():
    model=pickle.load(open('models\Diabetes_Prediction_Model.pkl','rb'))
    int_features = [int(x) for x in request.form.values()]
    input_data_as_numpy_array= np.asarray(int_features)

    input_data_reshaped = input_data_as_numpy_array.reshape(1,-1)

    prediction = model.predict(input_data_reshaped)
    output = '{0:{1}f}'.format(prediction[0], 2)

    if output == str(0):
        return render_template("result.html", pred="You are SAFE!!")
    else:
        return render_template("result.html", pred="You have diabetes")
    

if __name__ == '__main__':
    app.run(debug=True)
